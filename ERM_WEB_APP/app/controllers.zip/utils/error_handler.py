from flask import jsonify, current_app

def register_error_handlers(app):

    @app.errorhandler(Exception)
    def handle_exception(e):
        current_app.logger.error(f"Unhandled Exception: {str(e)}")
        return jsonify({
            "status": "error",
            "message": "Something went wrong"
        }), 500