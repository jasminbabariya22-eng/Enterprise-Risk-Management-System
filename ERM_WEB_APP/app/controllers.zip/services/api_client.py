import requests
from flask import current_app, session

class APIClient:

    @staticmethod
    def post(endpoint, data, headers=None ):
        try:
            current_app.logger.info(f"endpoint: {endpoint}")
            current_app.logger.info(f"Json data: {data}")
            current_app.logger.info(f"Json URL: {current_app.config['BASE_API_URL']}/{endpoint}")
            response = requests.post(
                f"{current_app.config['BASE_API_URL']}/{endpoint}",
                json=data,
               # headers=headers,
               # timeout=current_app.config["API_TIMEOUT"]
            )
            #response.raise_for_status()
            current_app.logger.info(f"Api Response(post) : {response}")
            return response
            
        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API POST Error: {str(e)}")
            raise


    @staticmethod
    def postdata(endpoint, data, headers=None):
        try:
            token = session.get("token")
            current_app.logger.info(f"{current_app.config['BASE_API_URL']}/{endpoint}")
            current_app.logger.info(f"Token(postdata): {token}")
            current_app.logger.info(f"data from auth:{data}")
            default_headers = {
                "Content-Type": "application/json"
            }

            if token:
                default_headers["Authorization"] = f"Bearer {token}"

            if headers:
                default_headers.update(headers)

            response = requests.post(
                f"{current_app.config['BASE_API_URL']}/{endpoint}",
                json=data,
                headers=default_headers,
                timeout=current_app.config["API_TIMEOUT"]
            )
            current_app.logger.error(f"API Response Received")
            return response

        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API POST Error: {str(e)}")
            raise


    @staticmethod
    def getbyid(endpoint, data, headers=None):
        try:
            token = session.get("token")
            current_app.logger.info(f"Token(getbyid): {token}")
            current_app.logger.info(f"{current_app.config['BASE_API_URL']}/{endpoint}/{data}")
            deptid=data
            current_app.logger.info(f"getbyid data Id {data}")
            default_headers = {
                "Content-Type": "application/json"
            }

            if token:
                default_headers["Authorization"] = f"Bearer {token}"

            if headers:
                default_headers.update(headers)
            response = requests.get(
                f"{current_app.config['BASE_API_URL']}/{endpoint}/{data}",
                headers=default_headers,
                timeout=current_app.config["API_TIMEOUT"]
            )
            response.raise_for_status()
            current_app.logger.info(f"getbyid data responce {response}")
            return response

        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API GET Error: {str(e)}")
            raise

    @staticmethod
    def putdataold(endpoint, data, headers=None):
        try:
            token = session.get("token")
            current_app.logger.info(f"Token(putdataold): {token}")
            deptid=data
            current_app.logger.info(f"Put data by Id {data}")
            default_headers = {
                "Content-Type": "application/json"
            }

            if token:
                default_headers["Authorization"] = f"Bearer {token}"

            if headers:
                default_headers.update(headers)
            response = requests.put(
                f"{current_app.config['BASE_API_URL']}/{endpoint}/{data}",
                headers=default_headers,
                timeout=current_app.config["API_TIMEOUT"]
            )
            response.raise_for_status()
            current_app.logger.info(f"Update Dept responce {response}")
            return response

        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API GET Error: {str(e)}")
            raise

    @staticmethod
    def putdata(endpoint, data, headers=None):
    
        try:
        
            token = session.get("token")
    
            default_headers = {
                "Content-Type": "application/json"
            }
    
            if token:
                default_headers["Authorization"] = f"Bearer {token}"
    
            if headers:
                default_headers.update(headers)
    
            response = requests.put(
                f"{current_app.config['BASE_API_URL']}/{endpoint}",
                json=data,
                headers=default_headers,
                timeout=current_app.config["API_TIMEOUT"]
            )
    
            response.raise_for_status()
    
            return response
    
        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API PUT Error: {str(e)}")
            raise

    @staticmethod
    def getdata(endpoint, headers=None):

       try:
           token = session.get("token")

           default_headers = {
               "Content-Type": "application/json"
           }

           if token:
               default_headers["Authorization"] = f"Bearer {token}"

           if headers:
               default_headers.update(headers)

           response = requests.get(
               f"{current_app.config['BASE_API_URL']}/{endpoint}",
               headers=default_headers,
               timeout=current_app.config["API_TIMEOUT"]
           )

           response.raise_for_status()

           return response

       except requests.exceptions.RequestException as e:
           current_app.logger.error(f"API GET Error: {str(e)}")
           raise

    @staticmethod
    def get(endpoint, headers=None):
        try:
            response = requests.get(
                f"{current_app.config['BASE_API_URL']}/{endpoint}",
                headers=headers,
                timeout=current_app.config["API_TIMEOUT"]
            )
            response.raise_for_status()
            return response

        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API GET Error: {str(e)}")
            raise

    @staticmethod
    def postdatafileold(endpoint, data, headers=None, files=None):
        try:
            token = session.get("token")
    
            default_headers = {}
    
            if token:
                default_headers["Authorization"] = f"Bearer {token}"
    
            if headers:
                default_headers.update(headers)
    
            url = f"{current_app.config['BASE_API_URL']}/{endpoint}"
    
            current_app.logger.info(f"URL: {url}")
            current_app.logger.info(f"Data: {data}")
            current_app.logger.info(f"Files: {files}")
            if files:
                response = requests.post(
                    url,
                    data=data,     
                    files=files,   
                    headers=default_headers,
                    timeout=current_app.config["API_TIMEOUT"]
                )
            else:
                default_headers["Content-Type"] = "application/json"
                response = requests.post(
                    url,
                    json=data,
                    headers=default_headers,
                    timeout=current_app.config["API_TIMEOUT"]
                )
            return response
        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API POST Error: {str(e)}")
            raise
    
    @staticmethod
    def postdatafile(endpoint, data, headers=None, files=None):
        try:
            token = session.get("token")

            default_headers = {}

            if token:
                default_headers["Authorization"] = f"Bearer {token}"

            if headers:
                default_headers.update(headers)

            url = f"{current_app.config['BASE_API_URL']}/{endpoint}"

            current_app.logger.info(f"URL: {url}")
            current_app.logger.info(f"Data: {data}")
            current_app.logger.info(f"Files: {files}")

            response = requests.post(
                url,
                data=data,      
                files=files or {},  
                headers=default_headers,
                timeout=current_app.config["API_TIMEOUT"]
            )

            return response

        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API POST Error: {str(e)}")
            raise

    @staticmethod
    def deletebyid(endpoint, headers=None):
        try:
            token = session.get("token")
            current_app.logger.info(f"Token(deletebyid): {token}")
            default_headers = {
                "Content-Type": "application/json"
            }

            if token:
                default_headers["Authorization"] = f"Bearer {token}"

            if headers:
                default_headers.update(headers)
            response = requests.delete(
                f"{current_app.config['BASE_API_URL']}/{endpoint}",
                headers=default_headers,
                timeout=current_app.config["API_TIMEOUT"]
            )
            response.raise_for_status()
            current_app.logger.info(f"deletebyid data responce {response}")
            return response

        except requests.exceptions.RequestException as e:
            current_app.logger.error(f"API GET Error: {str(e)}")
            raise
